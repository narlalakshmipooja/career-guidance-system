import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function getCareerAdvice(interests: string[], skills: string[]) {
  const model = "gemini-3-flash-preview";
  const prompt = `As a professional career counselor, provide advice for a student with the following interests: ${interests.join(", ")} and skills: ${skills.join(", ")}. 
  Suggest 3 potential career paths and explain why they match. Provide a short roadmap for each.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error getting career advice:", error);
    return "I'm sorry, I couldn't generate career advice at this moment. Please try again later.";
  }
}

export async function getResourceRecommendations(careerPath: string) {
  const model = "gemini-3-flash-preview";
  const prompt = `Suggest 5 high-quality learning resources (articles, courses, or videos) for someone interested in becoming a ${careerPath}. 
  Format the output as a JSON array of objects with 'title', 'type', and 'description' fields.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Error getting resource recommendations:", error);
    return [];
  }
}
